from flask import Flask
from public import public
from admin import admin


app=Flask(__name__)

app.secret_key="ddd"
app.register_blueprint(public)
app.register_blueprint(admin)


app.run(debug=True,port=5080,host="0.0.0.0")