from flask import *
from database import *

public=Blueprint("public",__name__)

@public.route('/')
def public_home():
	return render_template("public_home.html")

	
@public.route('/login',methods=['post','get'])
def login():
	if 'Login' in request.form:
		Uname=request.form['name']
		Passwd=request.form['password']
		check="select * from login where Username='%s'and Password='%s'"%(Uname,Passwd)
		fd=select(check)
		if fd:
			session['Login_id']=fd[0]['Login_id']

			if fd[0]['Usertype']=='admin':
				flash("Login Success.........!")
				return redirect(url_for('admin.admin_home'))
				
			
			else:
				
				flash("Login failed")
	return render_template("login.html")

